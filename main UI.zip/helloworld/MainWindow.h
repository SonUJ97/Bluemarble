#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#endif // MAINWINDOW_H
MainWindow::MainWindow(QWidget *parent) :
        QMainWindow(parent),
        ui(new Ui::MainWindow)
{
    ui -> setupUi(this);
    QPixmap pix();
}
